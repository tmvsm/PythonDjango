from django.shortcuts import render
from django.http import HttpResponse
from .models import Utilizador, Produto
from django.utils import timezone
from django.core.mail import send_mail


def index(request):
    return render(request, 'login/index.html')

def login(request):
    return render(request, 'login/login.html')

def logon(request):

    m = Utilizador.objects.get(email = request.POST['email'])

    if m.password == request.POST['password']:
        request.session['email'] = m.email
        return render(request, 'login/index.html')

    return render(request, 'login/index.html')


def registar(request):
    return render(request, 'login/regista.html')

def sendmail(request):
    return render(request, 'login/mail.html')

def checkout(request):

    prods = request.GET['ids']
    lista_produtos = prods.split(',')

    produtos = Produto.objects.filter(code__in = lista_produtos)

    print(produtos)

    return render(request, 'login/checkout.html', {'lista_produtos': produtos})

def register(request):
    return render(request, 'login/register.html')

def saveregister(request):
    u = Utilizador(first_name=request.POST['first_name'], last_name=request.POST['last_name'], email=request.POST['email'], password=request.POST['password'])
    u.save()

    return render(request, 'login/index.html')

def products(request):

    produtos = Produto.objects.all()

    for produto in produtos:
        print(produto.image)

    return render(request, 'login/products.html', {'produtos': produtos})

def single(request):


    p = request.GET['id']

    produto = Produto.objects.filter(code = p)


    return render(request, 'login/single.html',{'produto': produto})

def send_mail_final(request):

    send_mail('Subject here', 'Here is the message.', 'nabo@banana.pt',
    ['tiserafim1993@gmail.com'], fail_silently=False)


    return render(request, 'login/index.html')

def products_protein(request):

    produtos = Produto.objects.filter(categoria='Protein')

    return render(request, 'login/products.html', {'produtos': produtos})

def products_whey(request):

    produtos = Produto.objects.filter(sub_categoria='Whey')

    return render(request, 'login/products.html', {'produtos': produtos})

def products_iso(request):

    produtos = Produto.objects.filter(sub_categoria='Iso')

    return render(request, 'login/products.html', {'produtos': produtos})

def products_vitamins(request):

    produtos = Produto.objects.filter(categoria='Vitamins')

    return render(request, 'login/products.html', {'produtos': produtos})

def products_multi_vitamins(request):

    produtos = Produto.objects.filter(sub_categoria='Multi-vitamins')

    return render(request, 'login/products.html', {'produtos': produtos})

def products_omega(request):

    produtos = Produto.objects.filter(sub_categoria='Omega')

    return render(request, 'login/products.html', {'produtos': produtos})

def products_creatine(request):

    produtos = Produto.objects.filter(categoria='Creatine')

    return render(request, 'login/products.html', {'produtos': produtos})

def products_creatine_mono(request):

    produtos = Produto.objects.filter(sub_categoria='Mono-hidrated')

    return render(request, 'login/products.html', {'produtos': produtos})

def products_amino(request):

    produtos = Produto.objects.filter(categoria='Amino')

    return render(request, 'login/products.html', {'produtos': produtos})

def products_bcaa(request):

    produtos = Produto.objects.filter(sub_categoria='BCAA')

    return render(request, 'login/products.html', {'produtos': produtos})




