from django.conf.urls import url
from . import views

app_name = "login"

urlpatterns = [ url(r'^index/$', views.index, name='index'),
                url(r'^login/$', views.login, name='login'), #URL Logi
                url(r'^sendmail/$', views.sendmail, name='sendmail'), #URL send email
                url(r'^checkout/$', views.checkout, name='checkout'), #URL checkout
                url(r'^register/$', views.register, name='register'),
                url(r'^saveregister/$', views.saveregister, name='saveregister'),
                url(r'^products/$', views.products, name='products'), #URL register
                url(r'^logon/$', views.logon, name='logon'),
                url(r'^single/$', views.single, name='single'),
                url(r'^send_mail_final/$', views.send_mail_final, name='send_mail_final'),
                url(r'^products_protein/$', views.products_protein, name='products_protein'),
                url(r'^products_whey/$', views.products_whey, name='products_whey'),
                url(r'^products_iso/$', views.products_iso, name='products_iso'),
                url(r'^products_vitamins/$', views.products_vitamins, name='products_vitamins'),
                url(r'^products_omega/$', views.products_omega, name='products_omega'),
                url(r'^products_multi_vitamins/$', views.products_multi_vitamins, name='products_multi_vitamins'),
                url(r'^products_amino/$', views.products_amino, name='products_amino'),
                url(r'^products_bcaa/$', views.products_bcaa, name='products_bcaa'),
                url(r'^products_creatine/$', views.products_creatine, name='products_creatine'),
                url(r'^products_creatine_mono/$', views.products_creatine_mono, name='products_creatine_mono'),]

