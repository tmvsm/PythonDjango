from django.db import models

# Create your models here.
# Create DataBase tables here

from django.db import models

class Utilizador(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email = models.EmailField(max_length=100)
    password = models.CharField(max_length=100)

class Produto(models.Model):
    name = models.CharField(max_length=100)
    code = models.CharField(max_length=20)
    price = models.CharField(max_length=10)
    description = models.CharField(max_length=300)
    image = models.CharField(max_length=200)
    categoria = models.CharField(max_length=100)
    sub_categoria = models.CharField(max_length=100)
    full_description = models.CharField(max_length=800)

class Categoria(models.Model):
    name = models.CharField(max_length=100)

class Sub_Categoria(models.Model):
    name = models.CharField(max_length=100)
    categoria = models.ForeignKey(Categoria, on_delete=models.CASCADE)

"""
class Opcao(models.Model):
    questao = models.ForeignKey(Questao, on_delete=models.CASCADE)
    opcao_texto = models.CharField(max_length=200)
    votos = models.IntegerField(default=0)
"""