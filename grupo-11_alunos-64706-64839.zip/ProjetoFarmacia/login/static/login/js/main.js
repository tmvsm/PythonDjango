
//PHARM MONSTRO SCRIPT

$(document).ready(function(){

    $(document).on("click",".item_add",function() {
        var product_id = $(this).attr("id");
        var id = product_id.split("-")[1];

		var current_cart = localStorage.getItem("cart");
		var appendProduct = "";

		if(current_cart == null)
		    appendProduct = id
		else
		    appendProduct = current_cart + "," + id

        localStorage.setItem("cart", appendProduct);

    });

    $(document).on("click", ".simpleCart_empty", function() {
        localStorage.removeItem("cart");
    });

    $(document).on("click", "#cart-checkout", function() {
        var cart = localStorage.getItem("cart");

        window.location.href = "/login/checkout/?ids=" + cart;

    });

});
